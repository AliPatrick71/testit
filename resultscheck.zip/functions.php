<?php
//check if the username exists for a user
 
 
function usernameCheck($conn, $username){
    //sql query
    $sql = "SELECT username FROM student WHERE  username = 'username'";
    $query = mysqli_query($conn, $sql);
   
    //check if a result is retrieved
    if(mysqli_num_rows($query) > 0){
        $result = mysqli_fetch_array($query);
        $dbusername = $result['username'];
       
      if($username == $dbusername){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}