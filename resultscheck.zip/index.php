<?php 
session_start();
$msg1=''; $msg2=''; $msg3=''; $msg4=''; $username=''; $regno='';

require_once ('config.php');
require_once ('functions.php');


//check for form submission
if(isset($_POST['submit'])){
	$username = mysqli_real_escape_string($conn, htmlspecialchars($_POST['username'], ENT_QUOTES, 'utf-8'));
	$regno = mysqli_real_escape_string($conn, htmlspecialchars($_POST['regno'], ENT_QUOTES, 'utf-8'));

	//form validation
	if(empty($username)){
		$msg1 = "<div class='alert alert-danger' 
					style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>Username is required!!
				</div>";
	}elseif(!usernameCheck($conn, $username)){
		$msg1 = "<div class='alert alert-danger' 
					style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>Username does not exist!!
				</div>";
	}elseif(empty($regno)){
		$msg2 = "<div class='alert alert-danger' 
					style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>Please insert your registration number!!
				</div>";
	}elseif(empty($_POST['checkbox'])){
		$msg3 = "<div class='alert alert-danger' 
					style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>To continue, kindly accept academic terms!!
				</div>";
	}else{
	//check if user password matches database password
		$sql = "SELECT * FROM student WHERE username = '$username'";
		$query = mysqli_query($conn, $sql);

		if(mysqli_num_rows($query) > 0){
			$result = mysqli_fetch_array($query);
			$dbregno = $result['regNO'];
			$dbusername = $result['username'];

			if($dbusername = $username && $dbregno == $regno){
				//generate a pin for the user
				$generated_pin = rand(1000, 99999);
				$sql = "UPDATE student SET exam_pin = '$generated_pin' WHERE username = '$username'";
				$query = mysqli_query($conn, $sql);

				if($query){
					$_SESSION['username'] = $username;
					$msg3 = "<div class='alert alert-success' 
								style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>You have successfully logged in!!
								<span style='color: #4b7f80'>redirecting...</span>
									<meta http-equiv='refresh' content='4; dashboard.php'>
							</div>";
				}else{
					$msg4 = "<div class='alert alert-danger' 
								style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>An error occurred, please try again!!
							</div>";
				}

			}else{
				$msg4 = "<div class='alert alert-danger' 
							style='width: 351px; height: auto; padding-top: 0; margin-top: 2px;'>Kindly doublecheck your details!!
						</div>";
				}
		}
		
	}
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<title>Patrick Ali Academy Results Checking Portal</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Results Checker Portal Application" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<!-- css files -->
<link href="css/style.css" type="text/css" rel="stylesheet" media="all">
<link href="//fonts.googleapis.com/css?family=Ubuntu:300,300i,400,400i,500,500i,700,700i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- //css files -->
</head>
<!-- body starts -->
<body>
<!-- section -->
<section class="register">
	<div class="register-full">
		<div class="register-right">
			<div class="register-in">
				<h1>Welcome to Patrick Ali Academy Results Checking Portal</h1>
				<p>To continue, please log in with your portal username and registration number.</p>
				<?= $msg4; ?>
				<div class="register-form">
					<form action="index.php" method="post">
						<div class="fields-grid">
							<div class="styled-input agile-styled-input-top">
							
								<span></span>
							</div>
							<div class="styled-input">
								<input type="text" name="username" value="<?php echo $username; ?>"> 
								<label>Username</label>
								<span></span>
								<?= $msg1; ?>
							</div> 
							<div class="styled-input">
								<input type="password" name="regno" value="<?php echo $regno; ?>">
								<label>Enter Registration Number</label>
								<span></span>
								<?= $msg2; ?>
							</div>
							
							<div class="clear"> </div>
							 <label class="checkbox"><input type="checkbox" name="checkbox" checked><i></i>I agree to the <a href="#">Terms and Conditions</a></label>
							 <?= $msg3; ?>
							</div>
						<input type="submit" value="Submit to continue" name="submit">
					</form>
				</div>
<!--				<div class="registerimg">
					<img src="images/img.png" alt="" />
				</div>
			<div class="clear"> </div>
		</div>
		</div>  -->
	<div class="clear"> </div>
</div>
	<!-- copyright -->
	<p class="agile-copyright">© 2020 Patrick Ali Academy Results Checking Portal. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank">Universal Solutions</a></p>
	<!-- //copyright -->
</section>
<!-- //section -->
<script>
	if(window.history.replaceState){
		window.history.replaceState(null, null, window.href);
	}

</script>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>	
<!-- //body ends -->
</html>